# code_selenium_python_ebook

Code for the selenium pythion ebook
