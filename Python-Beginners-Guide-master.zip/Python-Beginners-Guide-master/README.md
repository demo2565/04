Sample Programs to teach python 
