# tamil-sandhi-checker
[![Build Status](https://travis-ci.org/Ezhil-Language-Foundation/tamil-sandhi-checker.png)](https://travis-ci.org/Ezhil-Language-Foundation/tamil-sandhi-checker) 

Tamil Sandhi Checker is a project created and maintained by Nithya Duraisamy, with contributions from Ezhil Language Foundation.

It is distributed under terms of GNU GPLv3.

