from .sandhi_checker import run_sandhi_checker_command_line

run_sandhi_checker_command_line()

