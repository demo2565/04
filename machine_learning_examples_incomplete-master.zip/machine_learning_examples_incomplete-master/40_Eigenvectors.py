import numpy as np
w, v = np.linalg.eig(np.array([[1, -2], [2, -3]]))
w; v
