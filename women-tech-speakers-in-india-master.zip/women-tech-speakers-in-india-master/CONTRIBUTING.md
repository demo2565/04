Add these details:

Location: __________ (Example: Bangalore)

Talks about: _______, ________, _______ (Example: Javascript, React, Data visualisation, etc.)

Social: ______, ______, ______ (Example: link to twitter, medium, linkedin, etc)

Consent given to contact: ✅ or 🚫(Is it okay for conference organisers to contact directly)

Preferred contact method: What's the preferred method of contact (email address/linkedin message/twitter DM, etc.)
