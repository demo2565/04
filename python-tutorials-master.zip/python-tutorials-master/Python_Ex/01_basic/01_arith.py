"""Arithmetic operation - program"""

#Get the two Numbers
a=input("Enter 1st Number: ")
b=input("Enter 2nd Number: ")

#Addition
print("Addition of %d and %d : %d" %(a,b,(a+b)))

#Subtraction
print("Subtraction of %d and %d : %d" %(a,b,(a-b)))

#Multiplication
print("Multiplication of %d and %d : %d" %(a,b,(a*b)))

#Division
print("Division of %d and %d : %d" %(a,b,(float(a)/b)))

#Madulas
print("Madulas of %d and %d : %d" %(a,b,(a%b)))
