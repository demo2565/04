"""This program to counting the words in given input"""

#input the given input string
str1 = raw_input("Enter the string:");

#create empty dictionary
dic={}
#split
str2=str1.split()
print str1
print "\n"
print str2


