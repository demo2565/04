"""This  is My first python program"""

#initialize my details

Name = "Manimaran"
Clg = "UCEV"
Num = 4024

#print the details

print(Name)
print(Clg)
print(Num)
print("My Name: %s" % Name)
print("College: %s" % Clg)
print("Num: %d" % Num)

#one line  print

print("\n\nMy Name: %s\t College: %s\t Num: %d" %(Name,Clg,Num))
