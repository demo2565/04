"""Range start,end,diffent value"""
print "start 10 end 101 diff 2" 
print range(10,101,2)
print "start 50 end 10 diff -5" 
print range(50,10,-5)
