#Joined the Two strings then printed it
hilarious = False
joke_evaluation = "Isn't that joke so funny?! %r"
print joke_evaluation  % hilarious
