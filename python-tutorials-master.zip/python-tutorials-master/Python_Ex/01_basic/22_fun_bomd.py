#fun use only
print "Just for Fun you view below...."
while True:
    for i in ["/","- ","|","\\","|"]:
        print "%s\r" % i,
