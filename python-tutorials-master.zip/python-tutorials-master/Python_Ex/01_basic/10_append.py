"""Append fun Using"""

#create empty fn
student_details=[]
for i in range(0,5):
    value=raw_input("Enter the value: ")
    student_details.append(value)

#print values one by one using for loop
for i in student_details:
    print i
