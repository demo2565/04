#import function
def test():
    print("Hai mani")
