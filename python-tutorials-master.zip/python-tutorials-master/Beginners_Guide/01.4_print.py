print ('hello {0}, {1}, {2} and {3}'.format('Nithya','seeni','viyan','kavitha'))
