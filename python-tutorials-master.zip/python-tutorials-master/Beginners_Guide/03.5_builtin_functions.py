names = 'Kavitha Manoharan,Aarthi Raj,kumaresan Jagadeesan'
print len(names)