num1 = 100
num2 = 200
num3 = 300
if num1>num2:
    if num1>num3:
        print "The greatest number is %r" %num1
elif num2>num3:
    print "The greatest number is %r" %num2
else:
    print "The greatest number is %r" %num3