txt = open("exercises.txt")
print txt.read()
txt.close()