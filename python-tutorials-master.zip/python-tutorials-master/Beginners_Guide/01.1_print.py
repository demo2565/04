print 'hello world'
#best code
