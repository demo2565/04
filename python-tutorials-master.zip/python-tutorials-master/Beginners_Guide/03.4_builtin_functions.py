names = 'Kavitha Manoharan,Aarthi Raj,kumaresan Jagadeesan'
print (names.lower())