list3 = [1,'two',3,'four',5,['another','list']]
print ('hybrid list : {}'.format(list3))