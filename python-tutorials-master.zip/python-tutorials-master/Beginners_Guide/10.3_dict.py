dic = {1:'One','Name':'Nithya','Age':25,'Qualification':'B.C.A'}
for i in dic:
    print i
