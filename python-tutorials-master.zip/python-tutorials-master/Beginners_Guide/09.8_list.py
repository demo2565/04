list2 = ['Freedom','and','the','future','of','the','internet']
print (' '.join(list2))
