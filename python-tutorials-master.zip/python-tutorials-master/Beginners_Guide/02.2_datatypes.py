a = 1.33
print type(a)
