a = 1
print type(a)
