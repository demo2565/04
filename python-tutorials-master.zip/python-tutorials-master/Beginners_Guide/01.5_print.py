print """
This simple book is meant to get you started in programming.
The title says it is the hard way to learn to write code.
but it is actually not.
"""