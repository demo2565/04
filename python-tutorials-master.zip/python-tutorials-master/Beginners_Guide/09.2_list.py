list1 = [1,2,3,4,5,6,7,8,9]
list1[5]='Mahesh'
print list1