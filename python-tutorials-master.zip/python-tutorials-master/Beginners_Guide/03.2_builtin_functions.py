names = 'Kavitha Manoharan,Aarthi Raj,kumaresan Jagadeesan'
print (names.replace(',','\n').replace(' ','-'))
