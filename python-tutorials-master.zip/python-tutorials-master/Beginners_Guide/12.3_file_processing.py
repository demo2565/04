txt = open("exercises.txt")
print txt.read()
txt.seek(0)
print txt.readline()
txt.close()


