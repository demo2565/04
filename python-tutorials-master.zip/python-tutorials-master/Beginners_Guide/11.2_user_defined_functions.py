x = int(raw_input("Enter 1st number"))
y = int(raw_input("Enter 2nd number"))
def add(x,y):
    return (x+y)
def sub(x,y):
    return(x-y)
addi = add(x,y)
subt = sub(x,y)
print addi,subt