dic = {1:'One','Name':'Nithya','Age':25,'Qualification':'B.C.A'}
print dic['Age']