print 3+5
#print 3+5 < 1+1 
#print "Addition of 3 & 5:",3+5 