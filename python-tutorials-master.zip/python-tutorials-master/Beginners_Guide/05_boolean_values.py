a,b,c,d,e,f = 0,1,2.34, '5 six seven','',None
print (bool(a))