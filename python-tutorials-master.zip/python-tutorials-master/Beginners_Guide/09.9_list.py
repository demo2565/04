list1 = ['Nithya Duraisamy','Vijaya Kandasamy','Anitha Rajagopal']
list2 = ['Freedom','and','the','future','of','the','internet']
print list1+list2