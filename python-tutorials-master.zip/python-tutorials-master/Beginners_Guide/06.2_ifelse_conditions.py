num1 = 100
num2 = 200
if num1>num2:
    print "%r is greater than %r" %(num1,num2)
else:
    print "%r is greater than %r" %(num2,num1)
