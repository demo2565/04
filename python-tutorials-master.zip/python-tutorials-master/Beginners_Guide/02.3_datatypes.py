a = [1,3,4,9]
print type(a)
