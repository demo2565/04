list1 = []
for i in range(1,10):
    list1.append(i)
print list1
