num1 = 168
if num1<100:
    print 'Execute this part'
