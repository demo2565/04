a = {1:'one', 'two' : 2, 2.3 : 'what', 'biteme' :12}
print type(a)
