x,y,z = 2,3,2
print ( (x != y) and (x>y) )
