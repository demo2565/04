a = (1,9,7)
print type(a)
