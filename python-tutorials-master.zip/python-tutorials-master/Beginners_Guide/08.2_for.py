for i in 'Very lucky day':
	print (i)
