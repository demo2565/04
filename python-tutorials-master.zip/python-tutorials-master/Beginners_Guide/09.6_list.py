list1 = [1,2,3,4,5,6,7,8,9]
print (list1[4:9])
#print (list1[6:])
#print (list1[:10])
#print (list1[-11])
#print (list1[4:12:2])
#print (list1[-13: :3])