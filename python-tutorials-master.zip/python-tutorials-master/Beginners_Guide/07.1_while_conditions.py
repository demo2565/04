z=0
while z<5:
	print( 'z = ' + str(z) )
	z += 1 # z = z+1

