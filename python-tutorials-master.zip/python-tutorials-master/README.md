Example programs for python tutorial
