print ("Hello world")
