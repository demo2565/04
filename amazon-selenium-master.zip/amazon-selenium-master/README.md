Script to automate amazon with selenium and python


# Task


1. Open Amazon.in in firefox
2. search for "data catalog"
3. Get result page
4. Check for first result
5. Get the book title
6. Get the author name
7. Get Paperback price
8. Get Hardcover Price


## Missing : 
Missed to select "Books" on the dropdown list in the home page.



### Language of Choice: 
Python

#### Reasons : 
It is powerful high level language. It provides required modules for all the automation requirements. Anyone can learn it faster.


### Test Framework : 
Unittest for Python

##### Reasons : 
unittest supports test automation, sharing of setup and shutdown code for tests, aggregation of tests into collections, and independence of the tests from the reporting framework. The unittest module provides classes that make it easy to support these qualities for a set of tests.


### Browser : 
Mozilla Firefox

#### Reasons :
Free/Open Source Software. 
Protects Privacy
Provides great speed



