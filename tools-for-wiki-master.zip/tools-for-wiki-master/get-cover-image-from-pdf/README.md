This script will do the follwing things to all the PDF files in current folder.

1. extract first page from all pdf files
2. convert them to PNG images


It uses pdftk and imagemagick tools.

To install them in ubuntu, run the following command.

```
sudo apt-get install pdftk imagemagick
```
