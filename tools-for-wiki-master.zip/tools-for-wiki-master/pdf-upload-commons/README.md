
This script uploads PDF, DJVU files in the current folder to wikimedia commons.
This is special script created to upload public domain books from Tamil Virtual University.
It has all the meta info to mention these details.

Dont use for regular purpose.


Install wikitools python module befir running it.

```
sudo pip install wikitools
```

