PDF Stats
=========

This program gives the statistics like name, page count, file size of the PDF files in the current folder.


Run these commands  to install the essential libraries.

```
sudo pip install pypdftk
sudo pip install humanize
```

