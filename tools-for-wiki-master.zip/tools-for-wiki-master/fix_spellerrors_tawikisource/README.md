This tool will find and replace the frequest spell errors on Tamil WikiSource pages.

The list of fixes are update here :
https://ta.wikisource.org/wiki/விக்கிமூலம்:தானியக்க_மெய்ப்பு/பிழைகள்_பட்டியல்

Install:
========

This program uses pywikibot python module.

To install it, run the following command.

```
sudo pip install pywikibot --pre
```

Then, fill the user-config.py with your wiki username.

Then, run

```
python replace_words_wikisource.py
```

It will run and replace the errored words.



Contact:
========

T Shrinivasan
tshrinivasan@gmail.com
