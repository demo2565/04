mylang='ta'
family='wikisource'
usernames['wikisource']['ta'] = u'TshrinivasanBOT'
