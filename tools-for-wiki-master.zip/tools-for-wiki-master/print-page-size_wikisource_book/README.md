This program will help to find the page size for all the pages in the books of wikisource.

Note:
====

The results are written in the file name with the given book name.

Now, the pages with size below 1000 bytes are written on the file.

If you want to change the size, change in line 80 in the file find-page-size.py



Todo:

Add support for other indic languages.

