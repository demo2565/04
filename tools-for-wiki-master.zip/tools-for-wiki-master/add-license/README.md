Add License
===========

This program adds a pdf file to all the other pdf files given in a directory as first page.
