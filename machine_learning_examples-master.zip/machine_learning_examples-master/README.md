Example code for Machine Learning with scikit-learn python library.

License : GNU GPL

