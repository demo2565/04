Free-Tamil-Ebooks - Opensource ePub Reader
=================

Whenever I get bored at work, I develop some ideas into apps. Most of them don't go till the stage of getting published. I started this project with 2 things in mind, Need to read the books in [http://freetamilebooks.com](http://freetamilebooks.com) easily and the ebooks should reach more mobile readers.

I started this more as a rapid prototype. Most of the logic behind was done in around 10 hours. (Don't judge me!)

So, please feel free to dig this up and work on it. I am planning to give support to this project till I can. You can download the latest version from App Store - [https://itunes.apple.com/us/app/free-tamil-ebooks-fte-cc-licenced/id835915093?mt=8](https://itunes.apple.com/us/app/free-tamil-ebooks-fte-cc-licenced/id835915093?mt=8)

If you find any issues with the app or suggestions to improve, please report to me or give a pull request.


###TODO:
1. Better Documentation
2. Make the eBook reader part as a standalone library
