import numpy as np 

a1 = np.array([[-2,4],[2,5]])

print (a1)
print (a1.dtype)
print (type(a1))
print (a1.ndim)
print (a1.shape)
print (a1.size)
print (a1.nbytes)
print (a1.flags)
print (a1.itemsize) 

a1 = np.array([[-2+4j,4],[2,5]])
print (a1.itemsize) 
